﻿<?php
	print <<<EOT
	<head>
	<title>发票识别网</title>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="./image/ico.ico" />
	<link href="invoice.css" rel="stylesheet" type="text/css"/>
	</head>
EOT;
//链接数据库
include 'sql.php';
session_start();
$bb=$_SESSION['b'];
$user=$_SESSION['a'];

$sql="SELECT * FROM c where name='{$user}'";

$result1 = mysqli_query($link,$sql);
foreach($result1 as $row){
	$s=$row['password'];
	$fileuser=$row['file'];
	session_start();
	$_SESSION['file']=$fileuser;
}
print <<<EOT
	<h2 style='color: Orange;'>欢迎回来，尊贵的用户$user</h2>
EOT;
echo "<div class='showlist'>";
   function fileShow($dir){    
   	$ff=array();                       //遍历目录下的所有文件和文件夹
   	$x=1;
   
       $handle = opendir($dir);
       while($file = readdir($handle)){
            if($file !== '..' && $file !== '.'){
                $f = $dir.'/'.$file;
            if(is_file($f)){
            	 //代表文件夹
            	$s=$dir.'/'.$file;
            	$ff=array();
				if(substr($s,-4)=='xlsx' && substr($s,-9)!='data.xlsx'){
					$x++;
					array_push($ff,substr($s,-22));
     		print <<<EOT

<a href=$s>$file</a><br><br>
EOT;
}               
                    }else{  
                    fileShow($f);
                }
                    }
        }

   }
  

fileShow($fileuser); 
echo "</div>";
//判断是否登录...........................................................................
if($s=$bb && $s!=""){
//保存键值对file
session_start();
//echo "文件的名称是00000000000000".$fileuser;
include 'function.php';
//用户自己的文件夹
//用户自己的路径

$f=$fileuser;
error_reporting(0);

$down_load=$_GET['id'].'/data.xlsx';
require_once 'function.php';

print <<<EOT

<div class='file'>
	<form action="run.php" method="post" enctype="multipart/form-data" class="form">
	<input class='select_file' type="file" accept=".png,.jpeg,.jpg,.gif;"  name="myFile[]" multiple="multiple" title=" "/>
	<input type="submit" value="上传文件"/ class='uploading_files'  onclick="a()">
	</form>
EOT; 
if($_GET['download']==1){

$get=$_GET['id'];
$filename=date("Y-m-d").'-'.date("H-i-s").'.xlsx';
//更改前的名称
$down_load=$get.'data.xlsx';
//更改后的名称
$aftername=$get.$filename;

	$res = rename($down_load,$aftername);
	
	print <<<EOT
	<a href=$aftername id="download">
	<input type='button' value='下载' class='down_load'/>
	</a>		
	EOT;




}
print <<<EOT
	<div style="position: absolute" class="progress_bar" id="img">
    <img src="./image/进度条.gif" style="object-fit:cover;width:560px;margin-left: -87px;margin-top: -20px;height:60px;left:7vw;"/>
EOT;
echo "</div>";
print <<<EOT
	<script>
			function a(){
				
					
					document.getElementById("img").style.display="block";
			
					document.getElementById("download").style.display="none";
			
			}
		</script>
EOT;
  }else{
  	header("Location:index.html");
  }
  
?>
