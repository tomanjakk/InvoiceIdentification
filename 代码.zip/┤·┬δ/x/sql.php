<?php
$host='localhost';
$user='root';
$pass='18388543714a';
$db='a';
$link=mysqli_connect($host,$user,$pass,$db);
function getDir2($pathArry)
{
	$path = realpath($pathArry);
    //判断目录是否为空
    if(!file_exists($path)) {
        return "";
    }
    $fileItem = [];
    //切换如当前目录
    chdir($path);
    foreach(glob('*') as $v) {
        $newPath = $path . DIRECTORY_SEPARATOR . $v;
        if(is_dir($newPath)) {
            $fileItem = array_merge($fileItem,getDir2($newPath));
        }else if(is_file($newPath)) {

            $fileItem[] = $newPath;
        }
    }
	for($i=0;$i<count($fileItem,COUNT_NORMAL);$i++){
	$q=explode('\\',$fileItem[$i])[6];
echo "<p>文件名称：{$q}</p>";
echo "<a href='$pathArry{$q}'><button>下载</button></a>";
echo "<a href='invoice.php?ff={$fileItem[$i]}'>            <button>删除</button></a>";
echo "<hr>";
	}
}
function delete($filename){
if(file_exists($filename)){	
if (!unlink($filename)){
// echo ("Error deleting $file");
}else

{	
//	echo ("删除成功 $file");
header("Location:invoice.php");
}

} else {
//echo '文件不存在,可能路径添错了';
}
}
?>