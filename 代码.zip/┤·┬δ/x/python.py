# -*- coding: utf-8 -*-
import urllib.request
import urllib.parse
import json
import time
import base64
import os
import openpyxl
import sys

print(sys.argv[1])
class Get_Img_Information(object):
    # 定义全局变量，包括请求头，appcode，api接口
    def __init__(self):
        self.AppCode = "169fe64c2afb49f78e4ff4a30d0923c7"

        self.headers = {
            'Authorization': 'APPCODE ' + self.AppCode,
            'Content-Type': 'application/json; charset=UTF-8'
        }

        self.url_request = "https://ocrapi-invoice.taobao.com/ocrservice/invoice"

    # 定义拿取图片文件的函数
    def get_img_file(self,file_name):
        imagelist = []
        # 遍历文件夹，拿取图片名称存入列表并返回
        for parent, dirnames, filenames in os.walk(file_name):
            for filename in filenames:
                if filename.lower().endswith(
                        ('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
                    imagelist.append(os.path.join(parent, filename))
            return imagelist
    # 转码，将图片格式转化为api能够识别的，并且返回列表
    def encode_file(self,file_list):
        fin_list = []
        for file in file_list:
            with open(file, 'rb') as f:  # 以二进制读取本地图片
                data = f.read()
                encodestr = str(base64.b64encode(data), 'utf-8')
                fin_list.append(encodestr)
        return fin_list
    # 调用api接口，请求返回数据
    def posturl(self,url,dict):
        try:
            params = json.dumps(dict,skipkeys=True).encode(encoding='UTF8')
            req = urllib.request.Request(url, params, self.headers)
            r = urllib.request.urlopen(req)
            html = r.read()
            r.close()
            return html.decode("utf8")
        except urllib.error.HTTPError as e:
            print(e.code)
            print(e.read().decode("utf8"))
        time.sleep(1)
    # 集合上面的函数并且拿到返回后的数据
    def get_data(self):
        # a = self.get_sys()

        res = self.get_img_file(sys.argv[1])
        retun = self.encode_file(res)
        data_list = []
        for i in retun:
            dict = {'img': i}
            html = self.posturl(self.url_request,dict)
            fin_data = json.loads(html)
            data_list.append(fin_data)
        return data_list

    # 解析数据，将数据解析为可以读懂的数据
    def fin_data_list(self,data):

        data_list = []
        key_list = []
        new_value_list = []
        for da in data:
            xiang = da['data']
            del xiang['发票详单']
            del xiang['发票代码解析']
            data_list.append(xiang)
        for i in data_list:
            for key in i.keys():
                key_list.append(key)
            new_value_list.append(key_list)
            break

        for i in data_list:
            value_list = []
            for value in i.values():
                if value == u'':
                    value = '无'
                    value_list.append(value)
                else:
                    value_list.append(value)
            new_value_list.append(value_list)
        return new_value_list

    # 将解析好的数据写入excel，并且保存
    def write_excel_xlsx(self,path, sheet_name, value):
        index = len(value)
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = sheet_name
        for i in range(0, index):
            for j in range(0, len(value[i])):
                sheet.cell(row=i + 1, column=j + 1, value=str(value[i][j]))
        workbook.save(path)
    # 定义run函数，让整个代码跑起来
    def run_all(self):
        # a = self.get_sys()
        path =sys.argv[1] + 'data.xlsx'
        sheet_name = 'data'
        data = self.get_data()
        new_data = self.fin_data_list(data)
        self.write_excel_xlsx(path,sheet_name,new_data)

    # def get_sys(self):
    #     # a = sys.argv[1]
    #     a="D:/桌面/imgs"

# 主函数
if __name__ == '__main__':
    spider = Get_Img_Information()
    spider.run_all()
    print('1')





