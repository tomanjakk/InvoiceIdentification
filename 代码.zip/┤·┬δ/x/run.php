﻿<?php
//本机python.exe路径
$python="C:\python\python8\python.exe";
//控制下载按钮的显示和隐藏
$download=0;
// 拿到file
session_start();
$f=$_SESSION['file'];

$unalterable=$f.'/'.md5(uniqid(microtime(true),true)).'/';
header("content-type:text/html;charset=utf-8");
require_once 'function.php';

$files=getFiles();
// 允许上传文件的类型
$allowExt=array('jpeg','jpg','png','gif');
//遍历
foreach($files as $fileInfo){
	$download=1;
	print_r($files);
     $res=uploadFile($fileInfo,$unalterable,false,$allowExt);
    echo '<br>';
    $uploadFiles[]=$res['dest'];
}
$a=exec("{$python} python.py  {$unalterable}",$out,$res);
header("Location:invoice.php?id=$unalterable&download=$download");
?>