<?php
//登录.....................................................................
$host='localhost';
$user='root';
$pass='18388543714a';
$db='a';
$db=mysqli_connect($host,$user,$pass,$db);
$yhm=$_GET['user_name'];
$mima=$_GET['password'];
$query="SELECT password FROM `c` where name='{$yhm}'";
$result=mysqli_query($db,$query);
foreach($result as $row){
	$s=$row['password'];
}
if($s==$mima && $mima!="" && $yhm!=""){

	session_start();
	$_SESSION['a']=$yhm;
	$_SESSION['b'] = $mima;
	
	header("Location:invoice.php");
}else{
	header("Location:index.html");
}

//注册.............................................................
if($_GET['registration_user']){
$registration_user=$_GET['registration_user'];
$registration_password=$_GET['registration_password'];
$host='localhost';
$user='root';
$pass='18388543714a';
$db='a';
$db=mysqli_connect($host,$user,$pass,$db);//连接

if (!$db) {
     die('连接错误 (' . mysqli_connect_errno() . ') '
             . mysqli_connect_error());
}
$file="1/".md5(uniqid(microtime(true),true));
$query2="insert into c values(null,'{$registration_user}','{$registration_password}','{$file}')";
$query=mysqli_query($db,$query2);
if($query){
     echo '插入数据成功！';
if(!file_exists($file)){
            mkdir($file,0777,true);}
}else{
     printf("错误消息: %s\n", mysqli_error($db));
}
header("Location:index.html");
}
?>